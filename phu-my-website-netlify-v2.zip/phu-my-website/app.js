const $=(s,p=document)=>p.querySelector(s), $$=(s,p=document)=>[...p.querySelectorAll(s)];
const places=[
 {id:'dam',name:'Đầm Trà Ổ – Đầm Châu Trúc',kind:'nature',category:'water',query:'Đầm Trà Ổ, Bình Dương, Gia Lai, Việt Nam',desc:'Đầm Trà Ổ, còn gọi là đầm Châu Trúc hoặc Bàu Bàng, là đầm nước tự nhiên ở vùng Phù Mỹ cũ. Theo thông tin quy hoạch khu vực năm 2026, lòng đầm có diện tích mặt nước khoảng 1.461 ha; khu vực quy hoạch trải trên địa bàn các xã Bình Dương, Phù Mỹ Đông và Phù Mỹ Bắc. Đây là vùng đất ngập nước có giá trị sinh thái, nguồn lợi thủy sản và vai trò điều tiết nước cho khu vực. Tôm đất và rạm từ đầm đã tạo nên hương vị riêng của bún tôm, bún rạm Phù Mỹ. Khi tham quan, hãy ưu tiên hoạt động có hướng dẫn của người dân, không xả rác và không làm ảnh hưởng vùng sinh thái.',link:'https://phumybac.gialai.gov.vn/tin-tuc/kinh-te-tong-hop/gia-lai-danh-thuc-dam-nuoc-ngot-tra-o-bang-khu-nghi-duong-bat-dong-san-san-golf2.html'},
 {id:'myan',name:'Biển Xuân Thạnh – Mỹ An',kind:'nature',category:'coast',query:'Biển Xuân Thạnh Nam Mỹ An, Phù Mỹ Đông, Gia Lai, Việt Nam',desc:'Bãi biển của làng chài Xuân Thạnh, trước đây thuộc xã Mỹ An, huyện Phù Mỹ và hiện thuộc xã Phù Mỹ Đông. Mỏm đá Gành Méc chia bờ biển thành Bãi Trước – nơi thuyền ghe gắn với sinh kế làng chài – và Bãi Sau yên tĩnh hơn, có dải cát vàng và nước biển xanh. Nơi đây phù hợp để ngắm cảnh, tìm hiểu đời sống ngư dân và thưởng thức hải sản trong ngày. Dịch vụ còn giản dị, vì vậy nên chuẩn bị nước uống, giữ vệ sinh và hỏi người dân về điều kiện biển trước khi tắm.',link:'https://govietnam.travel/destination/xuan-thanh-nam-my-an-beach/'},
 {id:'virong',name:'Mũi Vi Rồng',kind:'nature',category:'coast',query:'Mũi Vi Rồng, Phù Mỹ Đông, Gia Lai, Việt Nam',desc:'Mũi Vi Rồng nằm ở khu vực Mỹ Thọ cũ, nay thuộc xã Phù Mỹ Đông. Ghềnh đá nhô ra biển với các phiến đá xếp lớp tự nhiên gợi hình vảy rồng; sóng tràn qua khe đá tạo nên cảnh quan ấn tượng. Nơi đây còn gắn với làng chài Mỹ Thọ và nhịp sống nghề biển. Truyền thuyết về “Đá Vảy Rồng” là câu chuyện dân gian được lưu truyền, nên được hiểu như một lớp văn hóa dân gian chứ không phải lời giải thích địa chất.',link:'https://govietnam.travel/destination/vi-rong-cape-dragon-fin-cape/'},
 {id:'chanhtrach',name:'Làng bí đao khổng lồ Chánh Trạch',kind:'culture',category:'rural',query:'Làng bí đao khổng lồ Chánh Trạch, Phù Mỹ Đông, Gia Lai, Việt Nam',desc:'Làng Chánh Trạch thuộc xã Phù Mỹ Đông nổi tiếng với những giàn bí đao khổng lồ. Người trồng làm giàn chắc và dùng võng lưới đỡ từng quả để tránh sức nặng làm đứt dây; nhiều quả được báo chí ghi nhận có thể nặng khoảng 40–70 kg. Đây là điểm thú vị để tìm hiểu kỹ thuật canh tác và đời sống nhà nông. Nên hỏi người dân trước khi vào vườn hoặc chụp ảnh.',link:'https://vtcnews.vn/nguoi-dan-vung-bien-gia-lai-mac-vong-cho-bi-khong-lo-nang-70kg-ar1017286.html'},
 {id:'fishmarket',name:'Chợ cá làng chài Xuân Thạnh – Mỹ An',kind:'culture',category:'culture',query:'Chợ cá Mỹ An, Phù Mỹ Đông, Gia Lai, Việt Nam',desc:'Một lát cắt đời sống miền biển là phiên chợ cá lúc tinh mơ: thuyền về, cá tôm được chuyển vào bờ và tiểu thương chọn hàng cho buổi chợ. Hãy xem đây là không gian lao động của người dân; tránh cản lối vận chuyển, xin phép trước khi chụp chân dung và không tự ý bước lên thuyền.',link:'https://thanhnien.vn/binh-di-phien-cho-ca-duoi-chan-song-o-binh-dinh-185241015182709534.htm'},
 {id:'deonhong',name:'Di tích Chiến thắng Đèo Nhông – Dương Liễu',kind:'culture',category:'culture',query:'Khu di tích Chiến thắng Đèo Nhông Dương Liễu, Bình Dương, Gia Lai, Việt Nam',desc:'Khu di tích lịch sử cấp quốc gia trên địa bàn xã Bình Dương, tỉnh Gia Lai. Nơi đây ghi dấu chiến thắng Đèo Nhông – Dương Liễu tháng 2 năm 1965 và được địa phương tổ chức lễ kỷ niệm, dâng hương hằng năm. Khi đến thăm, giữ thái độ trang nghiêm và tuân thủ hướng dẫn tại khu tưởng niệm.',link:'https://vpub.gialai.gov.vn/tin-tu-tinh/gia-lai-ky-niem-61-nam-chien-thang-deo-nhong-duong-lieu.html'}
];
const foodInfo={
 banhxeo:['Bánh xèo tôm nhảy','Bánh xèo vàng giòn kết hợp tôm tươi, giá đỗ và rau sống. Khi ăn, cuốn bánh cùng rau rồi chấm nước mắm pha chua ngọt. Đây là món nổi tiếng trong ẩm thực Bình Định; hình ảnh minh họa là phong cách bánh xèo tôm nhảy vùng xứ Nẫu.','https://dulichviet.com.vn/am-thuc/banh-xeo-tom-nhay-binh-dinh-huong-vi-dam-da-cua-mien-dat-vo'],
 buntom:['Bún tôm Phù Mỹ','Một món ăn gắn với đầm Trà Ổ: tôm đất tươi được làm sạch, giã hoặc quết nhuyễn, nêm vừa phải rồi làm chín trong nồi nước dùng. Vị tôm ngọt thanh, thơm dịu, thường ăn với bún tươi và rau sống.','https://baogialai.com.vn/viewer.aspx?mabb=259082&macm=5&macmp=5'],
 bunram:['Bún rạm Phù Mỹ','Rạm từ đầm Trà Ổ được làm sạch, xay hoặc giã rồi lọc lấy nước cốt để nấu. Tô bún thường ăn cùng rau sống và bánh tráng nướng, nổi bật bởi vị ngọt tự nhiên và mùi thơm của rạm.','https://dantri.com.vn/du-lich/bun-tom-ram-nuc-tieng-phu-my-co-gi-dac-biet-ma-an-luc-2-3-to-van-thom-them-20220811170859143.htm'],
 buncha:['Bún chả cá','Bún chả cá phổ biến ở vùng duyên hải Bình Định: nước dùng thanh, chả cá dai thơm, thường ăn cùng rau, cà chua và gia vị. Đây là món ăn vùng miền, không phải món chỉ riêng xã Phù Mỹ.','https://www.premiergolftravel.vn/quy-nhon-ultimate-food-guide-2026-what-to-eat-where-to-find-it'],
 banhhoi:['Bánh hỏi lòng heo','Bánh hỏi làm từ bột gạo, sợi mảnh mềm, thường dùng cùng lòng heo, rau thơm, mỡ hành và nước mắm. Món ăn quen thuộc của ẩm thực Bình Định xưa.','https://vietnamtravel.com/overview-of-binh-dinh/'],
 nem:['Nem Chợ Huyện','Nem Chợ Huyện là đặc sản gắn với vùng Tuy Phước, Bình Định xưa. Nem có vị chua dịu, thơm, thường được gói bằng lá chuối và ăn kèm rau, tỏi, ớt. Website giới thiệu món này như đặc sản vùng Bình Định, không gán nguồn gốc riêng cho Phù Mỹ.','https://dulichquynhon.binhdinh.gov.vn/vi/olala'],
 seafood:['Hải sản miền biển','Ở làng chài Xuân Thạnh – Mỹ An, nhịp chợ sớm gắn với cá, tôm và các loại hải sản ngư dân đánh bắt gần bờ. Món ăn thay đổi theo mùa và mẻ lưới; nên hỏi giá, nguồn gốc và cách chế biến trước khi gọi món.','https://thanhnien.vn/binh-di-phien-cho-ca-duoi-chan-song-o-binh-dinh-185241015182709534.htm']
};
function openModal(title,text,link){$('#modalTitle').textContent=title;$('#modalText').textContent=text;$('#modalLink').href=link;$('#detailModal').classList.add('open');$('#detailModal').setAttribute('aria-hidden','false')}
function closeModal(){$('#detailModal').classList.remove('open');$('#detailModal').setAttribute('aria-hidden','true')}
$$('[data-close]').forEach(x=>x.addEventListener('click',closeModal));document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
$$('.explore-place').forEach(b=>b.addEventListener('click',()=>{let p=places.find(x=>x.id===b.dataset.place);openModal(p.name,p.desc,p.link)}));
$$('[data-food]').forEach(b=>b.addEventListener('click',()=>{let f=foodInfo[b.dataset.food];openModal(f[0],f[1],f[2])}));
$('#menuToggle').addEventListener('click',()=>$('#mainNav').classList.toggle('open'));
$$('#mainNav a').forEach(a=>a.addEventListener('click',()=>$('#mainNav').classList.remove('open')));

// Gentle reveal for sections.
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('seen');observer.unobserve(e.target)}}),{threshold:.12});
$$('.section-pad,.place-card,.food-feature,.culture-copy').forEach(el=>{el.classList.add('reveal-on-scroll');observer.observe(el)});

// Interactive map: geocode named places; no invented hard-coded pins.
let map, markers={};
function initMap(){
 if(!window.L){$('#mapStatus').textContent='Không tải được thư viện bản đồ. Hãy kiểm tra kết nối mạng.';return}
 map=L.map('map',{scrollWheelZoom:false}).setView([14.23,109.12],10);
 L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'&copy; OpenStreetMap'}).addTo(map);
 $('#mapStatus').textContent='Đang tra cứu vị trí địa danh…';
 Promise.all(places.map(async p=>{
  try{
   const r=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q='+encodeURIComponent(p.query),{headers:{'Accept-Language':'vi'}});
   const data=await r.json();if(data[0]){p.lat=+data[0].lat;p.lon=+data[0].lon;const m=L.marker([p.lat,p.lon]).bindPopup(`<b>${p.name}</b><br>${p.desc}`);markers[p.id]=m;m.addTo(map)}
  }catch(e){}
 })).then(()=>{$('#mapStatus').textContent='Đã hiển thị các vị trí tra cứu được. Chọn một điểm để xem trên bản đồ.';renderMapList('all')});
}
function renderMapList(filter){const list=$('#mapList');list.innerHTML='';places.filter(p=>filter==='all'||p.kind===filter).forEach(p=>{let b=document.createElement('button');b.className='map-point';b.innerHTML=`<b>${p.name}</b><small>${p.kind==='food'?'Ẩm thực':p.kind==='culture'?'Văn hóa':'Thiên nhiên'} · ${p.lat?'Đã tìm thấy vị trí':'Mở bản đồ tìm kiếm'}</small>`;b.addEventListener('click',()=>{if(p.lat&&map){map.setView([p.lat,p.lon],13);markers[p.id]?.openPopup()}else window.open('https://www.openstreetmap.org/search?query='+encodeURIComponent(p.query),'_blank','noopener')});list.appendChild(b)})}
$$('#mapFilters button').forEach(b=>b.addEventListener('click',()=>{$$('#mapFilters button').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderMapList(b.dataset.filter);places.forEach(p=>{if(markers[p.id]){if(b.dataset.filter==='all'||p.kind===b.dataset.filter)markers[p.id].addTo(map);else map.removeLayer(markers[p.id])}})}));
initMap();

// Quiz with 5 questions and countdown.
const questions=[
 {q:'Đầm Trà Ổ còn có tên gọi nào?',a:['Đầm Châu Trúc','Đầm Thị Nại','Đầm Đạm Thủy'],c:0,why:'Đầm Trà Ổ còn được gọi là đầm Châu Trúc hoặc Bàu Bàng.'},
 {q:'Đầm Trà Ổ thuộc khu vực nào của tỉnh Bình Định trước đây?',a:['Phù Mỹ','Tây Sơn','An Lão'],c:0,why:'Đầm Trà Ổ nằm ở phía Đông Bắc huyện Phù Mỹ cũ.'},
 {q:'Bánh hỏi thường được làm chủ yếu từ nguyên liệu nào?',a:['Bột gạo','Bột bắp','Khoai mì'],c:0,why:'Bánh hỏi được làm từ bột gạo, tạo thành những sợi nhỏ.'},
 {q:'Nem Chợ Huyện gắn với vùng nào của Bình Định xưa?',a:['Tuy Phước','Hoài Ân','Vĩnh Thạnh'],c:0,why:'Nem Chợ Huyện là đặc sản nổi tiếng gắn với vùng Tuy Phước.'},
 {q:'Điều gì gắn bó với đời sống làng chài ven biển?',a:['Thuyền đánh cá','Nương chè cao nguyên','Rừng thông ôn đới'],c:0,why:'Những chuyến thuyền ra khơi và trở về là một phần nhịp sống ven biển.'}
];
let qi=0,score=0,timeLeft=45,timer=null,locked=false;
function renderQuestion(){const area=$('#quizArea');if(qi>=questions.length){clearInterval(timer);area.innerHTML=`<b class="quiz-question">Hoàn thành rồi! 🎉</b><p>Bạn đạt <strong>${score}/${questions.length}</strong> điểm.</p><p>${score>=4?'Bạn có vốn hiểu biết rất tốt về vùng đất này!':'Một chuyến khám phá thực tế sẽ giúp bạn hiểu Phù Mỹ hơn.'}</p><button class="button button-dark" id="retryQuiz">Chơi lại ↻</button>`;$('#retryQuiz').onclick=startQuiz;return}
 const q=questions[qi];area.innerHTML=`<div class="quiz-progress">CÂU ${qi+1}/${questions.length} · ĐIỂM ${score}</div><div class="quiz-question">${q.q}</div><div class="quiz-answers">${q.a.map((a,i)=>`<button data-answer="${i}">${String.fromCharCode(65+i)}. ${a}</button>`).join('')}</div><div class="quiz-timer">⏱ Còn ${timeLeft} giây</div>`;
 $$('.quiz-answers button',area).forEach(b=>b.onclick=()=>answer(+b.dataset.answer));
}
function answer(n){if(locked)return;locked=true;let q=questions[qi];$$('.quiz-answers button',$('#quizArea')).forEach((b,i)=>{b.disabled=true;if(i===q.c)b.classList.add('correct');if(i===n&&n!==q.c)b.classList.add('wrong')});if(n===q.c)score++;$('.quiz-timer',$('#quizArea')).textContent=q.why;setTimeout(()=>{qi++;locked=false;renderQuestion()},1450)}
function startQuiz(){qi=0;score=0;timeLeft=45;locked=false;$('#quizArea').hidden=false;renderQuestion();clearInterval(timer);timer=setInterval(()=>{timeLeft--;let t=$('.quiz-timer',$('#quizArea'));if(t)t.textContent='⏱ Còn '+timeLeft+' giây';if(timeLeft<=0){clearInterval(timer);$('#quizArea').innerHTML=`<b class="quiz-question">Hết giờ!</b><p>Bạn đạt ${score}/${questions.length} điểm.</p><button class="button button-dark" id="retryQuiz">Chơi lại ↻</button>`;$('#retryQuiz').onclick=startQuiz}},1000)}
$('#startQuiz').addEventListener('click',startQuiz);

// Wheel is a discovery game, not a prize or betting mechanic.
let spinning=false,rotation=0;$('#spinWheel').addEventListener('click',()=>{if(spinning)return;spinning=true;let index=Math.floor(Math.random()*6);rotation+=1440+(360-index*60-30);$('#wheel').style.transform=`rotate(${rotation}deg)`;$('#wheelResult').textContent='Đang chọn điểm đến…';setTimeout(()=>{$('#wheelResult').textContent='Gợi ý dành cho bạn: '+['Đầm Trà Ổ','Bún tôm Phù Mỹ','Biển Xuân Thạnh – Mỹ An','Mũi Vi Rồng','Làng bí đao Chánh Trạch','Bún rạm Phù Mỹ'][index]+' ✨';spinning=false;playTone(660,.13)},3700)});

// Interest guide.
const guide={
 sea:'Hành trình gợi ý: ghé Biển Xuân Thạnh – Mỹ An, ngắm Gành Méc và tìm hiểu nhịp sống làng chài. Hãy hỏi người dân về điều kiện biển trước khi tắm.',
 food:'Hành trình gợi ý: thưởng thức bún tôm hoặc bún rạm Phù Mỹ – hai món gắn với nguồn tôm, rạm từ Đầm Trà Ổ; sau đó khám phá thêm món ngon vùng xứ Nẫu.',
 nature:'Hành trình gợi ý: khám phá Đầm Trà Ổ – Đầm Châu Trúc, quan sát cảnh quan đất ngập nước và tìm hiểu nghề đánh bắt truyền thống.',
 culture:'Hành trình gợi ý: ghé làng bí đao khổng lồ Chánh Trạch hoặc khu di tích Chiến thắng Đèo Nhông – Dương Liễu; dành thời gian nghe câu chuyện địa phương.'
};
$$('[data-interest]').forEach(b=>b.addEventListener('click',()=>{$$('[data-interest]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');$('#guideResult').textContent=guide[b.dataset.interest];playTone(520,.08)}));

// Local-only poll. A single vote per browser is retained in localStorage.
const voteKey='phumy-poll-v1',countKey='phumy-votes-v1';let votes=JSON.parse(localStorage.getItem(countKey)||'{"Đầm Trà Ổ":0,"Miền biển":0,"Làng quê":0}');
function drawPoll(){let total=Object.values(votes).reduce((a,b)=>a+b,0);$$('[data-vote]').forEach(b=>{let n=votes[b.dataset.vote]||0;b.querySelector('span').textContent=(total?Math.round(n/total*100):0)+'%';b.disabled=!!localStorage.getItem(voteKey);if(localStorage.getItem(voteKey)===b.dataset.vote)b.style.borderColor='var(--teal)'})}
$$('[data-vote]').forEach(b=>b.addEventListener('click',()=>{if(localStorage.getItem(voteKey))return;votes[b.dataset.vote]=(votes[b.dataset.vote]||0)+1;localStorage.setItem(countKey,JSON.stringify(votes));localStorage.setItem(voteKey,b.dataset.vote);$('#pollMessage').textContent='Cảm ơn bạn đã bình chọn!';drawPoll()}));drawPoll();

// Optional sound effects only; off by default.
let soundOn=false,audioCtx=null;
function playTone(freq=550,duration=.1){if(!soundOn)return;try{audioCtx=audioCtx||new(window.AudioContext||window.webkitAudioContext)();let o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=freq;o.type='sine';g.gain.setValueAtTime(.04,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+duration)}catch(e){}}
$('#soundToggle').addEventListener('click',()=>{soundOn=!soundOn;$('#soundToggle span').textContent='Âm thanh: '+(soundOn?'bật':'tắt');if(soundOn)playTone(660,.12)});
