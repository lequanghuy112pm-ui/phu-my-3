# PHÙ MỸ – CHẠM VÀO VẺ ĐẸP QUÊ HƯƠNG

Website tĩnh HTML/CSS/JavaScript, có thể triển khai trực tiếp lên Netlify.

## Chạy thử
- Giải nén thư mục.
- Mở `index.html` bằng trình duyệt hoặc dùng VS Code Live Server.
- Bản đồ, font và ảnh trực tuyến cần có kết nối Internet.

## Đưa lên Netlify
1. Truy cập https://app.netlify.com/drop
2. Kéo thả cả thư mục `phu-my-website` (hoặc giải nén ZIP rồi kéo thư mục) vào vùng upload.
3. Netlify tạo URL website sau khi triển khai.

## Tính năng
- Gallery mở rộng: Đầm Trà Ổ, Biển Xuân Thạnh – Mỹ An/Gành Méc, Mũi Vi Rồng, làng bí đao Chánh Trạch, chợ cá làng chài và di tích Đèo Nhông – Dương Liễu.
- Bộ sưu tập món ăn có ảnh: bánh xèo tôm nhảy, bún tôm, bún rạm, bánh hỏi lòng heo, bún chả cá, nem Chợ Huyện và hải sản.
- Navbar cố định, responsive cho điện thoại/máy tính.
- Gallery cảnh quan và modal nội dung.
- Bản đồ Leaflet + OpenStreetMap; tra cứu địa danh qua Nominatim theo tên, không gắn tọa độ phỏng đoán.
- Quiz 5 câu có đếm ngược, chấm điểm, chơi lại.
- Vòng quay gợi ý điểm đến/món ăn (không có tiền thưởng hay đặt cược).
- Gợi ý hành trình theo sở thích.
- Bình chọn lưu trên trình duyệt hiện tại bằng localStorage.
- Nút bật/tắt âm thanh hiệu ứng (mặc định tắt).

## Lưu ý độ chính xác địa lý
Theo Nghị quyết 1664/NQ-UBTVQH15, xã Phù Mỹ hiện nay được hình thành từ thị trấn Phù Mỹ, xã Mỹ Quang và xã Mỹ Chánh Tây. Đầm Trà Ổ thuộc vùng Phù Mỹ cũ nhưng hiện trải trên địa bàn các xã Bình Dương, Phù Mỹ Đông và Phù Mỹ Bắc; website ghi chú đây là điểm đến vùng lân cận, không gán nhầm vào địa giới xã Phù Mỹ hiện nay.

Các món ăn được giới thiệu như đặc sản phổ biến của vùng Bình Định xưa, không khẳng định tất cả đều có nguồn gốc riêng tại xã Phù Mỹ. Nem Chợ Huyện được ghi rõ gắn với vùng Tuy Phước.

## Ảnh và nguồn tư liệu
Ảnh được nhúng từ các trang báo/cổng thông tin và có thể thay đổi chính sách hotlink:
- Ảnh biển/đánh bắt khu vực Phù Mỹ: Dân Việt.
- Đầm Trà Ổ: Cổng Du lịch Quy Nhơn – Bình Định.
- Cảnh quan duyên hải: Báo Dân tộc và Phát triển.
- Bánh xèo tôm nhảy: Du lịch Việt Nam.
- Bánh hỏi lòng heo: aFamily.
- Nem Chợ Huyện: Cổng Du lịch Quy Nhơn – Bình Định.
- Chợ hải sản ven biển: VTC News.

Nếu ảnh bị chặn hotlink, hãy tải ảnh được phép sử dụng và thay URL trong `index.html`. Nên xin phép/chọn ảnh có giấy phép phù hợp khi phát hành công khai.

## Nguồn nội dung tham khảo
- Nghị quyết 1664/NQ-UBTVQH15: https://xaydungchinhsach.chinhphu.vn/toan-van-nghi-quyet-so-1664-nq-ubtvqh15-sap-xep-cac-dvhc-cap-xa-cua-tinh-gia-lai-nam-2025-119250616194200895.htm
- Đầm Trà Ổ: https://dulichquynhon.binhdinh.gov.vn/vi/damtrao
- Cổng thông tin xã Phù Mỹ: https://phumy.gialai.gov.vn/
- Bánh hỏi lòng heo: https://afamily.vn/chieu-mua-banh-hoi-long-heo-20220829162315747.chn
- Nem Chợ Huyện: https://dulichquynhon.binhdinh.gov.vn/vi/olala

## Nguồn bổ sung cho bản cập nhật
- Đầm Trà Ổ và quy hoạch vùng đầm: https://phumybac.gialai.gov.vn/tin-tuc/kinh-te-tong-hop/gia-lai-danh-thuc-dam-nuoc-ngot-tra-o-bang-khu-nghi-duong-bat-dong-san-san-golf2.html
- Biển Xuân Thạnh – Mỹ An, Gành Méc, Bãi Trước/Bãi Sau: https://govietnam.travel/destination/xuan-thanh-nam-my-an-beach/
- Mũi Vi Rồng: https://govietnam.travel/destination/vi-rong-cape-dragon-fin-cape/
- Làng bí đao khổng lồ Chánh Trạch: https://vtcnews.vn/nguoi-dan-vung-bien-gia-lai-mac-vong-cho-bi-khong-lo-nang-70kg-ar1017286.html
- Chợ cá ven biển Mỹ An: https://thanhnien.vn/binh-di-phien-cho-ca-duoi-chan-song-o-binh-dinh-185241015182709534.htm
- Di tích Chiến thắng Đèo Nhông – Dương Liễu, xã Bình Dương: https://vpub.gialai.gov.vn/tin-tu-tinh/gia-lai-ky-niem-61-nam-chien-thang-deo-nhong-duong-lieu.html
- Bún tôm, bún rạm Phù Mỹ: https://baogialai.com.vn/viewer.aspx?mabb=259082&macm=5&macmp=5 ; https://dantri.com.vn/du-lich/bun-tom-ram-nuc-tieng-phu-my-co-gi-dac-biet-ma-an-luc-2-3-to-van-thom-them-20220811170859143.htm
